Place your server and clients' identifiers here. 
node $TROUPE/rt/built/p2p/mkid.js --outfile=id-server.json
Gemerate public and private key with ID, used to link to trust map