Client 
    Client would have the server id as well as level of access.This allow client node to trust server allow it to communicate between node.
Server
    Will have the id from dating/ids for all nodes